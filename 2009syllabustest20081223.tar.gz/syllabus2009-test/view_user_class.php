<?php
	require_once('value.inc');
	require($session_start_php);
	
	$html_head = '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<title>';

if(($_POST['teacher']!= NULL) && ($_POST['password'] != NULL)){	//from $idex_php (or tring attack)
	$teacher = $_POST['teacher'];
	if(check_password(crypt($_POST['password'],'$1$'))){ //double or multi login
		if(isset($_SESSION['mode'])){
			//session_regenerate_id(true);
			require($session_end_php);
			require($session_start_php);
		}
		
		$_SESSION['teacher'] = $teacher;
		$_SESSION['mode'] = "internal";
		if($teacher == "root" || $_SESSION['root'] == 1){
			$root = 1;
		}elseif($teacher == $depart."_root" || $_SESSION['root'] == 2){
			$root = 2;
		}else{
			$root = 0;
		}
		$_SESSION['root']=$root;
		
		makelist();
	}
	
}elseif($_SESSION['mode'] == "internal"){		//Having being login
	$root = $_SESSION['root'];
	$teacher = $_SESSION['teacher'];
	makelist();
}elseif(($_POST['teacher'] == NULL)  || ($_POST['password'] == NULL)){	//teacher is NULL,or password is NULL ,or both are NULL.
	print $html_head."</title>\n</head>\n<body>教員IDまたはパスワードが未入力です。\n";
	print "<a href=\"{$index_php}\">こちら</a>からログインしなおして下さい。</body>\n</html>";
}else{	//bat access
	header("Location: $index_php");
}

function check_password($password){
	global $teacher,$index_php,$FILE_PASSWD;
	$teacher_exist = 0;
	$user = file($FILE_PASSWD) or die("open Error\n");
	foreach($user as $value){
		list($list_id,$list_pass) = explode(":",$value,5);
		if($list_id == $teacher) $teacher_exist = 1;
		$checkpass[$list_id] = rtrim($list_pass);
	}
	// パスワードの照合
	if($password == $checkpass[$teacher]){
		return true;
	}elseif($teacher_exist==0){
		print "教員IDが存在しません．\n";
		print "<a href=\"{$index_php}\">こちら</a>からログインしなおして下さい。</body>\n</html>";
	}else{
		print "IDとパスワードが一致しません．\n";
		print "<a href=\"{$index_php}\">こちら</a>からログインしなおして下さい。</body>\n</html>";
	}
	return false;
}

function makelist(){
	global $root,$teacher,$change_pass_php,$delete_user_php,$list_depart,$html_head;
	
	print $html_head;
	if($root != "1" || $root !=2){
		print htmlspecialchars($teacher,ENT_QUOTES,"UTF-8")."さんの";
	}
	print '科目一覧</title>
<link rel="stylesheet" href="css/SCS.css" type="text/css">
</head>
<body>';
	if($root == 1){
		print <<< HTML_END
<div class="head"><h1>科目一覧</h1>
<div align="right"><a class="attent" href="{$delete_user_php}">教員を選んで削除</a></div></div>

HTML_END;

	}
	else{
		print '<div class="head"><h1>'.htmlspecialchars($teacher,ENT_QUOTES,"UTF-8");
		print <<< HTML_END
さんの科目一覧</h1>
<div align="right"><a class="attent" href="{$delete_user_php}">教員削除</a></div></div>

HTML_END;

	}
	/*
	$list_depart = array(	"communication" => "情報通信工学科",
							"systems" => "情報システム工学科",
							"master-c" => "電子情報通信工学専攻",
							"master-s" => "機械情報システム工学専攻",
							"doctor" => "システム工学専攻");
	*/
	foreach($list_depart as $depart => $depart_ja){
		list_handle($depart,$depart_ja);
	}
	
	print <<< HTML_END
<div id="right">
	<a href="{$change_pass_php}">パスワード変更</a><br>
	<a href="./index.php?logout=1">ログアウト</a>
</div>
</body>
</html>
HTML_END;
}

function list_handle($depart,$depart_ja){
	global $root,$teacher,$change_pass_php,$regist_class_php,$delete_class_php,$edit_php;
	$list_txt			= "./data/".$depart."/xml/list.txt";
	$XML_PDF_D			= "./data/".$depart."/pdf/";
	$data = array();
	/*
	if($teacher == "root"){
		$root = 1;
	}
	elseif($teacher == $depart."_root"){
		$root = 2;
	}
	else{
		$root = 0;
	}
	*/
	if($root == 1 || $root == 2){
		print '<div align="center">
<div class="title"><h1>'.htmlspecialchars($depart_ja,ENT_QUOTES,"UTF-8").'</h1></div>
</div>
<table>
<tr class="ttitle">
	<td class="Grootsubjectname">科目名</td><td class="Grootid">教員ID(Mail)</td><td>更新完了</td><td>編集</td><td>削除</td>
</tr>';

		$check = file($list_txt);
		foreach($check as $value){
			array_push($data,rtrim($value));
		}
		sort($data);
		foreach($data as $value){
			list($page,$ok,$kamoku_ID,$teacher_ID,$kamoku_name) = explode(":",$value,5);
			if(file_exists($XML_PDF_D . $kamoku_ID . ".pdf")){
				$pdfexist = 1;
			}else{
				$pdfexist = 0;
			}
			
			if(!($kamoku_ID == "" || $teacher_ID == "" || $kamoku_name == "")){
				print '<tr>
	<td class="subjectname">';

			}
			if($pdfexist != 0){
				print '<a href="'.$XML_PDF_D.htmlspecialchars($kamoku_ID,ENT_QUOTES,"UTF-8").'.pdf" target="_blank">'.htmlspecialchars($kamoku_name,ENT_QUOTES,"UTF-8").'</a>';
			}
			else{
				print htmlspecialchars($kamoku_name,ENT_QUOTES,"UTF-8");
			}
			if(file_exists($XML_PDF_D.$kamoku_ID.".html")){
				print '(<a href="'.$XML_PDF_D.htmlspecialchars($kamoku_ID,ENT_QUOTES,"UTF-8").'.html" target="_blank">html</a>)';
			}
			
			print "</td>";
			print "\t<td>".htmlspecialchars($teacher_ID,ENT_QUOTES,"UTF-8")."</td>";
			if($ok == "0")	print "\t<td class=\"uncomp\">未完了</td>\n";
			else			print "\t<td class=\"comp\">完了</td>\n";
			print	"\t".'<td><a href="'.htmlspecialchars($edit_php.'?xmlfile='.$kamoku_ID.'.xml&depart='.$depart,ENT_QUOTES,"UTF-8").'">編集</a></td>
		<td><a href="'.htmlspecialchars($delete_class_php.'?kamokuID='.$kamoku_ID.'&depart='.$depart,ENT_QUOTES,"UTF-8")."\">削除</a></td>
</tr>";
		}
	}
	else{ // general user
		print '<div align="center">
<div class="title"><h1>'.htmlspecialchars($depart_ja,ENT_QUOTES,"UTF-8").'</h1></div>
</div>
<table>
<tr class="ttitle">
	<td class="Gnormalsubjectname">科目名</td><td>編集</td><td>印刷イメージ</td><td>更新完了</td><td>削除</td>
</tr>';

		$check = file($list_txt);// or die("open error");
		foreach($check as $value){
			list($page,$ok,$kamoku_ID,$teacher_ID,$kamoku_name) = explode(":",$value,5);
			$kamoku_name = rtrim($kamoku_name);
			if($teacher == $teacher_ID){
				print '<tr>
	<td class="subjectname">'.htmlspecialchars($kamoku_name,ENT_QUOTES,"UTF-8").'</td>
	<td><a href="'.htmlspecialchars($edit_php.'?xmlfile='.$kamoku_ID.'.xml&depart='.$depart,ENT_QUOTES,"UTF-8").'">編集</a></td>
	<td>';
				if(file_exists($XML_PDF_D.$kamoku_ID.".pdf")){
					print '<a href="'.htmlspecialchars($XML_PDF_D.$kamoku_ID,ENT_QUOTES,"UTF-8").'.pdf" target="_blank">PDF</a>';
				}
				if(file_exists($XML_PDF_D.$kamoku_ID.".html")){
					print '(<a href="'.htmlspecialchars($XML_PDF_D.$kamoku_ID,ENT_QUOTES,"UTF-8").'.html" target="_blank">html</a>)';
				}
				print "</td>\n";
				if($ok == "0")	print "\t<td class=\"uncomp\">未完了</td>\n";
				else			print "\t<td class=\"comp\">完了</td>\n";
			print "\t".'<td><a href="'.htmlspecialchars($delete_class_php.'?kamokuID='.$kamoku_ID.'&depart='.$depart,ENT_QUOTES,"UTF-8").'">削除</a></td>
</tr>';
			}
		}
	}

// 共通項目
	print <<< HTML_END
</table>
</div>
<div id="right">
	<a href="{$regist_class_php}?depart={$depart}">新規科目登録</a><br>
</div>

HTML_END;

}
?>
