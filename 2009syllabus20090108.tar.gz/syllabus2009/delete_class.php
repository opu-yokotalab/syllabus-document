<?php
require_once('value.inc');
require($session_start_php);
require($session_check_php);

if($_POST['mode'])			$mode = $_POST['mode'];

$root = $_SESSION['root'];

if($_POST['kamokuID'])		$kamokuID = $_POST['kamokuID'];
elseif($_GET['kamokuID'])	$kamokuID = $_GET['kamokuID'];

$teacher=$_SESSION['teacher'];

if($_POST['depart'])		$depart = $_POST['depart'];
elseif($_GET['depart'])		$depart = $_GET['depart'];

$list_txt		= "./data/".$depart."/xml/list.txt";
$list_txtnew	= "./data/".$depart."/xml/list.new";
$XML_D			= "./data/".$depart."/xml/";
$XML_PDF_D		= "./data/".$depart."/pdf/";

if($mode != "internal"){
	$check = file($list_txt) or die("open error");
	foreach($check as $value){
		list($page,$ok,$kamoku_ID_r,$teacher_ID,$kamoku_name_r) = explode(":",$value);
		if($kamokuID == $kamoku_ID_r){
			$kamoku_name = rtrim($kamoku_name_r);
		}
	}
	
	print <<<HTML_END
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html lang="ja">
<head>
<meta http-equiv="Content-type" content="text/html; charset=UTF-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<link rel="stylesheet" href="css/maintenance.css" type="text/css">
<title>科目削除</title></head>
<body>
HTML_END;

if((strpos($kamokuID,$_SESSION['teacher']) === false) && $root == 0){
	print 'ログインしなおしてください<br /><a href="'.$index_php.'?logout=1">トップページに戻る</a></body></html>';
		exit;
	}
	
print '<center>
<div class="head"><h1>科目の削除</h1></div>
<form method="POST" action="'.$delete_class_php.'">
<table>
<tr>
	<td>'.htmlspecialchars($kamoku_name,ENT_QUOTES,"UTF-8").'を削除してよろしいですか？</td>
</tr>
</table>';

print '<input type="hidden" name="kamokuID" value="'.htmlspecialchars($kamokuID,ENT_QUOTES,"UTF-8").'">';
print '<input type="hidden" name="mode" value="internal">';
print '<input type="hidden" name="depart" value="'.htmlspecialchars($depart,ENT_QUOTES,"UTF-8").'">';
print <<<HTML_END
<input type="submit" value="削除する">
<input type="button" value="削除せずに前の画面に戻る" onClick="history.back()">
</form>
</center>
</body>
</html>
HTML_END;
}

else{
	$list_out = array();
	
	$kamokuID =$_POST['kamokuID'];
	$check = file($list_txt) or die("open error");
	foreach($check as $value){
		list($page,$ok,$kamoku_ID_r,$teacher_ID,$kamoku_name_r) = explode(":",$value);
		if(rtrim($kamoku_ID_r) != $kamokuID){
			array_push($list_out,rtrim($value));
		}else{
			$kamoku_name = rtrim($kamoku_name_r);
		}
	}
	$OUT = fopen($list_txtnew,"w");
	foreach($list_out as $value){
		fwrite($OUT,$value."\n");
	}
	fclose($OUT);
	unlink($list_txt);
	rename($list_txtnew,$list_txt);
	
	unlink($XML_D.$kamokuID.".xml");
	if(file_exists($XML_PDF_D.$kamokuID.".pdf")) unlink($XML_PDF_D.$kamokuID.".pdf");
	//if(file_exists($XML_html_D.$kamokuID.".html")) unlink($XML_html_D.$kamokuID.".html");
	
	print <<<HTML_END
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html lang="ja">
<head>
<meta http-equiv="Content-type" content="text/html; charset=UTF-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<link rel="stylesheet" href="css/maintenance.css" type="text/css">
<title>削除完了</title>
</head>
<body>
<table>
<tr>
	<td>
HTML_END;

print htmlspecialchars($kamoku_name,ENT_QUOTES,"UTF-8")."を削除しました。</td>";

print <<<HTML_END
</tr>
<tr>
	<td><a href="{$view_user_class_php}">科目一覧に戻る</a></td>
</tr>
</table>
</body>
</html>
HTML_END;
}
