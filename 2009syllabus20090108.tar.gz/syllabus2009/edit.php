<?php
require_once('value.inc');

require($session_start_php);
require($session_check_php);

$teacher = $_SESSION['teacher'];

require_once('str2otf.php');

if($_POST['mode'])	 $mode = $_POST['mode'];

print <<< HTML_END
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ja" lang="ja">
<head>
<meta http-equiv="Content-type" content="text/html; charset=UTF-8" />
<meta http-equiv="Content-Style-Type" content="text/css" />
<title>シラバス内容編集画面</title>
<link rel="stylesheet" href="css/edit.css" type="text/css" />
</head>
<body>
HTML_END;
if($mode == "ed"){
	write();
}
else{
	ed();
}

function write(){
	global $teacher,$view_user_class_php,$index_php;

	$teacherID=$teacher;
	$depart = $_POST['depart'];
	$root = $_SESSION['root'];
	
	$name_ja				= binarycheck($_POST['name_ja']);
	$name_en				= binarycheck($_POST['name_en']);
	for($i=0;$i<2;$i++){
		$teacher_name[$i]	= binarycheck($_POST['teacher_name'.$i]);
		$teacher_attribute[$i]	= $_POST['teacher_attribute'.$i];
		if($teacher_attribute[$i] != "part"){
			$teacher_attribute[$i] = "full";
		}
		$room_num[$i]		= binarycheck($_POST['room_num'.$i]);
		$e_mail[$i]			= binarycheck($_POST['e_mail'.$i]);
		$grade[$i]			= binarycheck($_POST['grade'.$i]);
		$year[$i]			= binarycheck($_POST['year'.$i]);
	}
	$subject_form			= binarycheck($_POST['subject_form']);
	$choice					= binarycheck($_POST['choice']);
	$credit					= binarycheck($_POST['credit']);
	$outline				= binarycheck($_POST['outline']);
	$object					= binarycheck($_POST['object']);
	$attention_necessary	= binarycheck($_POST['attention_necessary']);
	$attention_others		= binarycheck($_POST['attention_others']);
	$subject_plan_attribute	= binarycheck($_POST['subject_plan_attribute']);
	$endtype				= $_POST['endtype'];
	if($subject_plan_attribute == "list"){
		for($i=0;$i<15;$i++){
			$subject_plan[$i] = binarycheck($_POST['subject_plan'.$i]);
		}
	}
	else{
		$subject_plan = binarycheck($_POST['subject_plan']);
	}
	$granding				= binarycheck($_POST['granding']);
	$relation				= binarycheck($_POST['relation']);
	$text_book				= binarycheck($_POST['text_book']);
	$text_books 			= split("\n",$text_book);
	$ref_book				= binarycheck($_POST['ref_book']);
	$ref_books 				= split("\n",$ref_book);
	$remark					= binarycheck($_POST['remark']);
	
	$simplefilename				= binarycheck($_POST['simplefilename']);
	if((strpos($simplefilename,$_SESSION['teacher']) === false) && $root == 0){
		print 'ログインしなおしてください<br /><a href="'.$index_php.'?logout=1">トップページに戻る</a></body></html>';
		exit;
	}
	
	$writefile				="./data/".$depart."/xml/".$simplefilename;//= binarycheck($_POST['writefile']);
	$XML = fopen($writefile,"w") or die("open error");
	$buf = <<< XML_END
<?xml version="1.0" encoding="UTF-8" ?>

<syllabus>
	<subject_name>
		<name_ja>{$name_ja}</name_ja>
		<name_en>{$name_en}</name_en>
	</subject_name>
	<teachers>

XML_END;
	for($i=0;$i<2;$i++){
		$buf .= <<< XML_END
		<teacher em_form="$teacher_attribute[$i]">
			<name>$teacher_name[$i]</name>
			<room_num>$room_num[$i]</room_num>
			<e_mail>$e_mail[$i]</e_mail>
		</teacher>

XML_END;
	}
	$buf .= <<< XML_END
	</teachers>
	<students>

XML_END;
	for($i=0;$i<2;$i++){
		$buf .= <<< XML_END
		<student>
			<grade>$grade[$i]</grade>
			<year>$year[$i]</year>
		</student>

XML_END;
	}
	$buf .= <<< XML_END
	</students>
	<subject_form>{$subject_form}</subject_form>
	<choice>{$choice}</choice>
	<credit>{$credit}</credit>
	<outline>

XML_END;
	$buf .= write_print_double($outline);
	$buf .= <<< XML_END
	</outline>
	<object>

XML_END;
	$buf .= write_print_double($object);
	$buf .= <<< XML_END
	</object>
	<attention>
		<necessary>

XML_END;
	$buf .= write_print_double($attention_necessary);
	$buf .= <<< XML_END
		</necessary>
		<others>

XML_END;
	$buf .= write_print_double($attention_others);
	$buf .= <<< XML_END
		</others>
	</attention>
	<subject_plan form="{$subject_plan_attribute}">

XML_END;
	if($subject_plan_attribute == "list"){
		for($i=0;$i<15;$i++){
			$buf .= "\t\t<li><p>".$subject_plan[$i]."</p></li>\n";
		}
	}
	else{
		$buf .= write_print_double($subject_plan);
	}
	$buf .= <<< XML_END
	</subject_plan>
	<granding>

XML_END;
	$buf .= write_print_double($granding);
	$buf .= <<< XML_END
	</granding>
	<text>
		<text_books>

XML_END;
	foreach($text_books as $value){
		$value = rtrim($value);
		$buf .= "\t\t\t<book>".$value."</book>\n";
	}
	$buf .= <<< XML_END
		</text_books>
		<ref_books>

XML_END;
	foreach($ref_books as $value){
		$value = rtrim($value);
		$buf .= "\t\t\t<book>".$value."</book>\n";
	}
	$buf .= <<< XML_END
		</ref_books>
	</text>
	<remark>

XML_END;
	$buf .= write_print_double($remark);
	$buf .= <<< XML_END
	</remark>
</syllabus>
XML_END;
	
	fwrite($XML,$buf);
	fclose($XML);
	
	changelist($name_ja,$endtype);
	print "<div class=\"head\"><h1>印刷イメージ生成</h1></div>\n";
	$err = make_pdf($depart,$simplefilename);
	
	if(!$err)	print "<p>PDFファイルを生成しました．</p>";
	else		print "<p>PDFファイル生成に失敗しました．<br/>入力項目を確認してください．</p>";
	
	print <<< HTML_END
<p><a href="{$view_user_class_php}">科目一覧画面に戻る</a></p>
</body>
</html>
HTML_END;
}

function binarycheck($binary){
	/*
	$repstr = array('<' => '＜',
					'>' => '＞',
					'_' => '＿',
					'&' => '＆',
					'\"' => '”'
	*/
//					'\\\'' => '’',
//					'#' => '＃',
//					'%' => '％',
//					'\\\\' => '￥'
	//				);
/*	
	$binary = preg_replace('/</','＜',$binary);
	$binary = preg_replace('/>/','＞',$binary);
	$binary = preg_replace('/_/','＿',$binary);
	$binary = preg_replace('/\"/','”',$binary);
	$binary = preg_replace('/#/','＃',$binary);
	$binary = preg_replace('/%/','％',$binary);
	//$binary = preg_replace('/[\x85-\x88][\x40-\x9E]|[\xEA-\xFC][\xA5-\xFC]/','',mb_convert_encoding($binary,"SJIS","EUC-JP")); //機種依存文字の処理
	//return mb_convert_encoding(rtrim($binary),"EUC-JP","SJIS");
*/
	//$binary = preg_replace('/\'/','’',$binary);

	//return mb_convert_encoding(rtrim(str_replace(array_keys($repstr),array_values($repstr),$binary)),"UTF-8","AUTO");
	
	return xml_ent(mb_convert_encoding(rtrim($binary),"UTF-8","AUTO"));

}
function write_print_double($str){
	$result_double = split("\n",$str);
	foreach($result_double as $value){
		$buf .= "\t\t<p>".rtrim($value)."</p>\n";
	}
	return $buf;
}

function ed(){
	global $teacher,$edit_php,$index_php;
$teacherID=$teacher;
$root = $_SESSION['root'];

	$xmlfile = $_GET['xmlfile'];
	$depart = $_GET['depart'];
	
	$XML_D= "./data/".$depart."/xml/";
	$receive_file = $XML_D.$xmlfile;
	
	//$writefile = $receive_file;
	$simplefilename = $xmlfile;
	
	if((strpos($simplefilename,$_SESSION['teacher']) === false) && $root == 0){
		print 'ログインしなおしてください<br /><a href="'.$index_php.'?logout=1">トップページに戻る</a></body></html>';
		exit;
	}
	
	$writefile				="./data/".$depart."/xml/".$simplefilename;//= binarycheck($_POST['writefile']);
	
	$xml = simplexml_load_file($receive_file);
	
	$endtype = getstate($simplefilename,$depart);
	if($endtype == "complete"){
		$end_t_r = "";
		$end_t_c = "checked";
	}
	else{
		$end_t_r = "checked";
		$end_t_c = "";
	}

	$name_ja				= $xml->subject_name->name_ja;
	$name_en				= $xml->subject_name->name_en;
	for($i=0;$i<2;$i++){
		$teacher_name[$i]	= $xml->teachers->teacher[$i]->name;
		if($xml->teachers->teacher[$i]['em_form'] == "part") $te_att[$i] = "checked";
		$room_num[$i]		= $xml->teachers->teacher[$i]->room_num;
		$e_mail[$i]			= $xml->teachers->teacher[$i]->e_mail;
		$grade[$i]			= $xml->students->student[$i]->grade;
		$year[$i]			= $xml->students->student[$i]->year;
	}
	$subject_form			= $xml->subject_form;
	$choice					= $xml->choice;
	$credit					= $xml->credit;
	$outline				= readvalue_double($xml->outline->p);
	$object					= readvalue_double($xml->object->p);
	$attention_necessary	= readvalue_double($xml->attention->necessary->p);
	$attention_others		= readvalue_double($xml->attention->others->p);
	$subject_plan_attribute	= $xml->subject_plan['form'];
	if($subject_plan_attribute == "list"){
		for($i=0;$i<=14;$i++){
			$subject_plan[$i] = $xml->subject_plan->li[$i]->p;
		}
		$su_pl_att_l = "checked";
		$su_pl_att_f = "";
	}
	else{
		$subject_plan		= readvalue_double($xml->subject_plan->p);
		$su_pl_att_l = "";
		$su_pl_att_f = "checked";
	}
	$granding				= readvalue_double($xml->granding->p);
	//$relation				= readvalue_double($xml->relation->p);
	$text_book				= readvalue_double($xml->text->text_books->book);
	$ref_book				= readvalue_double($xml->text->ref_books->book);
	$others					= $xml->contact->others;
	$remark					= readvalue_double($xml->remark->p);
	$page					= $xml->page;

	print '<div class="head"><h1>シラバス内容編集ページ</h1></div><br />
<div align="center"><div class="title"><h1>シラバス登録確認・変更フォーム</h1></div></div><br />
<form action="'.$edit_php.'" method="POST">
<input type="hidden" name="mode" value="ed" />
<input type="hidden" name="teacher_number" value="1" />
<input type="hidden" name="subject_plan_number" value="14" />
<input type="hidden" name="simplefilename" value="'.htmlSCU8($simplefilename).'" />
<input type="hidden" name="depart" value="'.$depart.'" />
<table id="edit" cellspacing="0">
<tr>
<th class="column" colspan="8">旧科目名の括弧は＜＞でお願いします。</th>
</tr>
<tr>
	<td class="column">日本語科目名<br />〈旧科目名〉</td>
	<td class="in" colspan="3"><input type="text" name="name_ja" size="50" value="'.htmlSCU8($name_ja).'" /></td>
	<td class="column">英語科目名<br />〈旧科目名〉</td>
	<td class="in" colspan="3"><input type="text" name="name_en" size="50" value="'.htmlSCU8($name_en).'" /></td>
</tr>
<tr>
	<td class="column">担当教員</td>
	<td class="in" colspan="3">
	<input type="text" name="teacher_name0" size="24" value="'.htmlSCU8($teacher_name[0]).'" /> <input type="checkbox" name="teacher_attribute0" value="part"'.htmlSCU8($te_att[0]).'/> 非常勤<br />
	<input type="text" name="teacher_name1" size="24" value="'.htmlSCU8($teacher_name[1]).'" /> <input type="checkbox" name="teacher_attribute1" value="part"'.htmlSCU8($te_att[1]).' /> 非常勤</td>
	<td class="column">担当教員への<br />連絡先</td>
	<td class="in" colspan="3">
		自室番号<input type="text" size="6" name="room_num0" value="'.htmlSCU8($room_num[0]).'" />, 電子メール<input type="text" size="30" name="e_mail0" value="'.htmlSCU8($e_mail[0]).'" /><br>
		自室番号<input type="text" size="6" name="room_num1" value="'.htmlSCU8($room_num[1]).'" />, 電子メール<input type="text" size="30" name="e_mail1" value="'.htmlSCU8($e_mail[1]).'" />
	</td>
</tr>
<tr>
	<td class="column">単位数</td>
	<td class="in" colspan="3">
	<select name="credit">
		<option value="'.htmlSCU8($credit).'">'.htmlSCU8($credit).'</option>
		<option value="2">2</option>
		<option value="1">1</option>
		<option value="3">3</option>
		<option value="4">4</option>
		<option value="8">8</option>
	</select>
</td>
</tr>
<tr>
	<td class="column">対象学生</td>
	<td class="in" colspan="5">
		<input type="text" name="grade0" size="20" value="'.htmlSCU8($grade[0]).'" />（平成<input type="text" name="year0" size="2" value="'.htmlSCU8($year[0]).'"/>年度以前入学生）<br/>
		<input type="text" name="grade1" size="20" value="'.htmlSCU8($grade[1]).'" />（平成<input type="text" name="year1" size="2" value="'.htmlSCU8($year[1]).'"/>年度以降入学生）
	</td>
</tr>

<tr>
	<td class="column">概略</td>
	<td class="in" colspan="7"><textarea cols="103" rows="5" name="outline">'.htmlSCU8($outline).'</textarea></td>
</tr>
<tr>
	<td class="column">授業科目の<br />目標</td>
	<td class="in" colspan="7"><textarea cols="103" rows="5" name="object">'.htmlSCU8($object).'</textarea></td>
</tr>
<tr>
	<td class="column" rowspan="2">履修上の注意</td>
	<td class="column">（履修の要件）</td>
	<td class="in" colspan="6"><input type="text" name="attention_necessary" value="'.htmlSCU8($attention_necessary).'" size="103" /></td>
</tr>
<tr>
	<td class="column">（その他）</td>
	<td class="in" colspan="6"><input type="text" name="attention_others" value="'.htmlSCU8($attention_others).'" size="103" /></td>
</tr>
<tr>
	<td class="column">授業計画の<br />記入方法</td>
	<td class="in" colspan="7">
	<input type="radio" name="subject_plan_attribute" value="list"'.$su_pl_att_l.' />スケジュール形式（推奨）
	<input type="radio" name="subject_plan_attribute" value="free"'.$su_pl_att_f.' />自由形式
	</td>
</tr>
<tr>
	<td class="column" rowspan="4">授業計画</td>
	<td class="column" colspan="7">スケジュール形式</td>
</tr>
<tr>
	<td colspan="7"><ol>';

	if($subject_plan_attribute == "list"){
		print "\t\t".'<li><input type="text" size="108" name="subject_plan0" value="'.htmlSCU8($subject_plan[0]).'" /></li>
		<li><input type="text" size="108" name="subject_plan1" value="'.htmlSCU8($subject_plan[1]).'" /></li>
		<li><input type="text" size="108" name="subject_plan2" value="'.htmlSCU8($subject_plan[2]).'" /></li>
		<li><input type="text" size="108" name="subject_plan3" value="'.htmlSCU8($subject_plan[3]).'" /></li>
		<li><input type="text" size="108" name="subject_plan4" value="'.htmlSCU8($subject_plan[4]).'" /></li>
		<li><input type="text" size="108" name="subject_plan5" value="'.htmlSCU8($subject_plan[5]).'" /></li>
		<li><input type="text" size="108" name="subject_plan6" value="'.htmlSCU8($subject_plan[6]).'" /></li>
		<li><input type="text" size="108" name="subject_plan7" value="'.htmlSCU8($subject_plan[7]).'" /></li>
		<li><input type="text" size="108" name="subject_plan8" value="'.htmlSCU8($subject_plan[8]).'" /></li>
		<li><input type="text" size="108" name="subject_plan9" value="'.htmlSCU8($subject_plan[9]).'" /></li>
		<li><input type="text" size="108" name="subject_plan10" value="'.htmlSCU8($subject_plan[10]).'" /></li>
		<li><input type="text" size="108" name="subject_plan11" value="'.htmlSCU8($subject_plan[11]).'" /></li>
		<li><input type="text" size="108" name="subject_plan12" value="'.htmlSCU8($subject_plan[12]).'" /></li>
		<li><input type="text" size="108" name="subject_plan13" value="'.htmlSCU8($subject_plan[13]).'" /></li>
		<li><input type="text" size="108" name="subject_plan14" value="'.htmlSCU8($subject_plan[14]).'" /></li>';
		
	}else{
		print <<< HTML_END
		<li><input type="text" size="108" name="subject_plan0" value="" /></li>
		<li><input type="text" size="108" name="subject_plan1" value="" /></li>
		<li><input type="text" size="108" name="subject_plan2" value="" /></li>
		<li><input type="text" size="108" name="subject_plan3" value="" /></li>
		<li><input type="text" size="108" name="subject_plan4" value="" /></li>
		<li><input type="text" size="108" name="subject_plan5" value="" /></li>
		<li><input type="text" size="108" name="subject_plan6" value="" /></li>
		<li><input type="text" size="108" name="subject_plan7" value="" /></li>
		<li><input type="text" size="108" name="subject_plan8" value="" /></li>
		<li><input type="text" size="108" name="subject_plan9" value="" /></li>
		<li><input type="text" size="108" name="subject_plan10" value="" /></li>
		<li><input type="text" size="108" name="subject_plan11" value="" /></li>
		<li><input type="text" size="108" name="subject_plan12" value="" /></li>
		<li><input type="text" size="108" name="subject_plan13" value="" /></li>
		<li><input type="text" size="108" name="subject_plan14" value="" /></li>

HTML_END;
	}
	print <<< HTML_END
	</ol></td>
</tr>
<tr>
	<td class="column" colspan="7">自由形式</td>
</tr>
<tr>
	<td colspan="7" class="in"><textarea cols="103" rows="15" name="subject_plan">
HTML_END;
	if($subject_plan_attribute != "list") print htmlSCU8($subject_plan);
	print '</textarea></td>
</tr>
<tr>
	<td class="column">成績評価</td>
	<td colspan="7" class="in"><textarea cols="103" rows="2" name="granding">'.htmlSCU8($granding).'</textarea></td>
</tr>
<!--
<tr>
	<td class="column">関連授業科目</td>
	<td colspan="7" class="in"><textarea cols="103" rows="2" name="relation">'.htmlSCU8($relation).'</textarea></td>
</tr>
-->
<tr>
	<td class="column" rowspan="2">教材</td>
	<td class="column">教科書</td>
	<td colspan="6" class="in"><textarea cols="87" rows="3" name="text_book">'.htmlSCU8($text_book).'</Textarea></td>
</tr>
<tr>
	<td class="column">参考書</td>
	<td colspan="6" class="in"><textarea cols="87" rows="3" name="ref_book">'.htmlSCU8($ref_book).'</textarea></td>
</tr>
<tr>
	<td class="column">備考</td>
	<td colspan="7" class="in"><textarea cols="103" rows="2" name="remark">'.htmlSCU8($remark).'</textarea></td>
</tr>
<tr>
	<td class="column" rowspan="2">編集メニュー</td>
	<td class="in" colspan="5"><input type="radio" name="endtype" value="reserve" '.$end_t_r.' />一時保存
		<span class="explan">
		・・・編集内容を一時的に保存する場合や<br />出来栄えの確認をする場合に選択してください。</span>
	</td>
	<td class="column" rowspan="2" align="center"><input type="submit" value="入力完了" /></td>
	<td class="column" rowspan="2" align="center"><input type="reset" value="全てやり直す" /></td>
</tr>
<tr>
	<td class="in" colspan="5"><input type="radio" name="endtype" value="complete"'.$end_t_c.' />完了
		<span class="explan">・・・編集が完了したときに選択してください。<br />
		(これを選択しても編集は可能ですが、製本時に次回以降の編集結果が反映されない可能性があります。)
		</span>
	</td>
</tr>
</table>
</form>
</body>
</html>';
}

function changelist($name_ja,$endtype){
	$data = array();
	$result = array();
	
	$depart = $_POST['depart'];
	$simplefilename = $_POST['simplefilename'];
	
	$XML_PDFD		= "./data/".$depart."/pdf/";
	$list_txt		= "./data/".$depart."/xml/list.txt";
	$list_txtnew	= "./data/".$depart."/xml/list.new";

	$name_ja_de = xml_ent_de($name_ja);
	
	$check = file($list_txt);
	foreach($check as $value){
		array_push($data,rtrim($value));
	}
	foreach($data as $value){
		list($page,$ok,$kamoku_ID,$teacher_ID,$kamoku_name) = explode(":",$value);
		$readdata_xml = $kamoku_ID.".xml";
		if($readdata_xml == $simplefilename){
			if($endtype == "complete"){
				$ok = "1";
			}
			else{
				$ok = "0";
			}
			/*
			if($page != $page_r){
				unlink($XML_PDF_D.$kamoku_ID.".pdf");
			}
			*/
			$setdata = $page.":".$ok.":".$kamoku_ID.":".$teacher_ID.":".$name_ja_de;
			array_push($result,$setdata);
		}
		else{
			array_push($result,$value);
		}
	}
	$OUT = fopen($list_txtnew,"w");
	foreach($result as $value){
		fwrite($OUT,$value."\n");
	}
	fclose($OUT);
	unlink($list_txt);
	rename($list_txtnew,$list_txt);
}

function getstate($simplefilename,$depart){
	$list_txt = "./data/".$depart."/xml/list.txt";
	$data = array();
	
	$check = file($list_txt) or die("open error");
	foreach($check as $value){
		array_push($data,rtrim($value));
	}
	foreach($data as $value){
		list($page,$ok,$kamoku_ID,$teacher_ID,$kamoku_name) = explode(":",$value);
		$readdata_xml = $kamoku_ID.".xml";
		if($readdata_xml == $simplefilename){
			if($ok == "1"){
				$endtype = "complete";
			}
			else{
				$endtype = "reserve";
			}
			return $endtype;
		}
	}
}

function readvalue_double($tag){
	foreach($tag as $value){
		$result .= $value."\n";
	}
	return $result;
}

function make_pdf($depart,$simplefilename){
	$XML_D		= "./data/".$depart."/xml/";
	$XML_PDF_D	= "./data/".$depart."/pdf/";
	$workdir	= "./data/".$depart."/workdir/";
	list($filename,$ext) = explode(".xml",$simplefilename);
	
	$xmlfile = $XML_D.$simplefilename;
	$xslfile = "./syllabus_pdf.xsl";
	$texfile = $workdir.$filename.".tex";
	$dvifile = $workdir.$filename.".dvi";
	$pdffile = $XML_PDF_D.$filename.".pdf";
	
	$xmlbuf = file($xmlfile);
	$buf = "";
	foreach($xmlbuf as $value){
		$buf .= str2otf($value);
		//$buf .= replaceText($value);
	}
		
	$xml = new DOMDocument;
	$xml->loadxml($buf);

	$xsl = new DOMDocument;
	$xsl->load($xslfile);
	
	$proc = new XSLTProcessor;
	$proc->importStyleSheet($xsl);
	
	$OUT = fopen($texfile,"w");
	$buf = $proc->transformToXML($xml);
	fwrite($OUT,$buf);
	fclose($OUT);
	
	if(file_exists($dvifile)) unlink($dvifile);
	exec('platex -kanji=utf8 -output-directory='.$workdir." ".$texfile);
	exec('dvipdfmx -o '.$pdffile." ".$dvifile);
	
	if(!file_exists($dvifile))	return 1;
	else						return 0;
}
function htmlSCU8($var){
 return htmlspecialchars($var,ENT_QUOTES/*,"UTF-8"*/);
}
function xml_ent($string){
	return preg_replace('/&#039;/','&apos;',htmlSCU8($string));
}
function xml_ent_de($string){
	return htmlspecialchars_decode(preg_replace('/&apos;/','\'',$string),ENT_QUOTES);
}
?>
