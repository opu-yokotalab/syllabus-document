<?php
require_once('value.inc');

print <<< HTML_END
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<link rel="stylesheet" href="css/SCS.css" type="text/css">
<title>登録済の科目一覧</title>
</head>
<body>
<div class="head_list"><h1>登録済の科目一覧(PDF閲覧のみ可能)</h1></div>

HTML_END;
/*
$output_depart = array(	"communication" => "情報通信工学科",
						"systems" => "情報システム工学科",
						"master-c" => "電子情報通信工学専攻",
						"master-s" => "機械情報システム工学専攻",
						"doctor" => "システム工学専攻");
*/
foreach($list_depart as $depart => $depart_ja){
	$list_txt	= "./data/".$depart."/xml/list.txt";
	$XML_D		= "./data/".$depart."/xml/";
	$XML_PDF_D	= "./data/".$depart."/pdf/";
	
	$check = file($list_txt);// or die("open error");
	$sorting = array();
	$lineout = array();
	
	foreach($check as $value){
		$line = explode(":",rtrim($value));
		$tmp = $line[0];
		$line[0] = $line[3];
		$line[3] = $tmp;
		array_push($sorting,$line);
	}
	sort($sorting);
	foreach($sorting as $value){
		$tmp = $value[0];
		$value[0] = $value[3];
		$value[3] = $tmp;
		$imp_value = implode(":",$value);
		array_push($lineout,$imp_value);
	}
	
	print "\t".'<div align="center"><div class="title_list"><h1>'.htmlspecialchars($depart_ja,ENT_QUOTES,"UTF-8").'</h1></div></div>
	<table>
	<tr class="ttitle">
		<td class="subjectname">科目名</td>
		<td class="Grootid">教員ID(Mail)</td>
		<td>最終更新日</td>
	</tr>';

	foreach($lineout as $value){
		list($page,$ok,$kamoku_ID,$teacher_ID,$kamoku_name) = explode(":",$value,5);
		$pdfexist = "";
		if(!file_exists($XML_PDF_D.$kamoku_ID.".pdf")) $pdfexist = "None";
		
		if(!($kamoku_ID == "" || $teacher_ID == "" || $kamoku_name == "")){
			print "\t<tr>\n\t\t<td class=\"subjectname\">";
			if($pdfexist != "None"){
				print "<a href=\"".htmlspecialchars($XML_PDF_D.$kamoku_ID,ENT_QUOTES,"UTF-8").".pdf\" target=\"_blank\">".$kamoku_name."</a>";
			}
			else{
				print htmlspecialchars($kamoku_name,ENT_QUOTES,"UTF-8");
			}
			print "</td>\n\t\t<td class=\"Grootid\">";
			
			if($teacher_ID != "root"){
				print htmlspecialchars($teacher_ID,ENT_QUOTES,"UTF-8");
			}
			else{
				print "管理者権限";
			}
			print "</td>\n\t\t<td>";
			
			if($pdfexist != "None"){
				$modtime = filemtime($XML_PDF_D.$kamoku_ID.".pdf");
				print date("Y",$modtime)."年".date("n",$modtime)."月".date("j",$modtime)."日";
			}
			print "</td>\n\t</tr>\n";
		}
	}
	print "</table><br><br>\n";
}

print <<< HTML_END
<a href="{$index_php}">トップページに戻る</a>
</body>
</html>
HTML_END;
