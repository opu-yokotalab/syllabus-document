<?php
require_once('value.inc');
require($session_start_php);
require($session_check_php);

$html_head='<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html lang="ja">
<head>
<meta http-equiv="Content-type" content="text/html; charset=UTF-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<link rel="stylesheet" href="css/maintenance.css" type="text/css">
<title>所有教員の変更</title>
</head>
<body>
<center>';

if(isset($_GET['select']) && isset($_GET['depart']) && $_SESSION['root'] != 0){
	$selectclass = $_GET['select'];
	$depart = $_GET['depart'];
	$list_txt = "./data/".$depart."/xml/list.txt";
	print $html_head;
	select_page($selectclass,$depart);
}elseif(isset($_POST['destteacher']) && isset($_POST['select']) && ( $_POST['mode'] == "internal") && isset($_POST['depart']) && $_SESSION['root'] !=0 ){
$selectclass = $_POST['select'];
$destteacher = $_POST['destteacher'];
$depart = $_POST['depart'];
	$list_txt = "./data/".$depart."/xml/list.txt";
	$list_txtnew = "./data/".$depart."/xml/list.new";
	$XML_D = "./data/".$depart."/xml/";
	print $html_head;
	change_page();
	print '</td>
	</tr>
</table>
<p><a href ="'.$view_user_class_php.'">一覧に戻る</a></p>
</body>
</html>';
}else{
	print $html_head.'invalid or unexpected access.</body></html>';
 //bad access
}
function select_page($selectclass,$depart){
	global $list_txt,$chown_class_php;

	$list_out = array();
	
	$check = file($list_txt) or die("open error");
	foreach($check as $value){
		list($page_r,$ok_r,$kamoku_ID_r,$teacher_ID_r,$kamoku_name_r) = explode(":",$value);
		if(rtrim($kamoku_ID_r) == $selectclass){
			$kamoku_name = rtrim($kamoku_name_r);
			$owner = rtrim($teacher_ID_r);
		}
	}
print '<div class="head"><h1>所有教員の変更</h1></div>
'.htmlspecialchars($kamoku_name,ENT_QUOTES,"UTF-8").'の新しい所有教員を選択してください。
<form method="POST" action="'.$chown_class_php.'">
<table id="box">
	<tr>
	<tr>
	<td>現在の所有教員：'.htmlspecialchars($owner,ENT_QUOTES,"UTF-8").'から</td>
	</tr>
	<td>';
	make_teacher_list();
	print 'の所有科目に変更</td>
	</tr>
</table>
<input type="hidden" name="mode" value="internal">
<input type="hidden" name="depart" value="'.htmlspecialchars($depart,ENT_QUOTES,"UTF-8").'">
<input type="hidden" name="select" value="'.htmlspecialchars($selectclass,ENT_QUOTES,"UTF-8").'">

<input type="submit" value="変更する">
</form>
</center>
</body>
</html>';
}
function change_page(){
	global $selectclass,$destteacher,$list_txt,$list_txtnew,$XML_D;
	$list_out = array();
	
	$check = file($list_txt) or die("open error:list");
	foreach($check as $value){
		list($page_r,$ok_r,$kamoku_ID_r,$teacher_ID_r,$kamoku_name_r) = explode(":",$value);
		if(rtrim($kamoku_ID_r) != $selectclass){
			array_push($list_out,rtrim($value));
		}else{
			$page = rtrim($page_r);
			$ok = rtrim($ok_r);
			$kamoku_name = rtrim($kamoku_name_r);
		}
	}
	
	$xmlfile = $destteacher.time();
	// XML
	$buf_f=file($XML_D.$selectclass.".xml") or die("open error:buf");
	$buf="";
	foreach($buf_f as $value){
		$buf.=$value;
	}
	$XML=fopen($XML_D.$xmlfile.".xml","w") or die ("open error:xml");
	fwrite($XML,$buf);
	fclose($XML);
	//delete old files
	unlink($XML_D.$selectclass.".xml");
	//unlink("./data/".$_GET['depart']/pdf/".$selectclass.".pdf");
	//unlink("./data/".$_GET['depart']/pdf/".$selectclass."./.tex");
	//unlink("./data/".$_GET['depart']/pdf/".$selectclass.".aux");
	//unlink("./data/".$_GET['depart']/pdf/".$selectclass.".dvi");
	//unlink("./data/".$_GET['depart']/pdf/".$selectclass.".log");
	
	// list.txtに科目ID，教員名，科目名を書き込む．
	$OUT = fopen($list_txtnew,'w') or die("open error");
	foreach($list_out as $value){
		fwrite($OUT,$value."\n");
	}
	fwrite($OUT,$page.":".$ok.":".$xmlfile.":".$destteacher.":".$kamoku_name."\n");
	fclose($OUT);
	unlink($list_txt);
	rename($list_txtnew,$list_txt);
	//unlink pdf
	print '<td>'.htmlspecialchars($kamoku_name."の所有者を".$destteacher."に変更しました。");
}

function make_teacher_list(){
	global $FILE_PASSWD;
	$check = file($FILE_PASSWD) or die("open error");
	$data = array();
	
	print <<< HTML_END
		<select name="destteacher">
			<option value="root">root</option>

HTML_END;
	foreach($check as $value){
		list($ID,$passwd) = split(":",$value);
		if($ID != "root"){
			array_push($data,$value);
		}
	}
	sort($data);
	foreach($data as $value){
		list($ID,$passwd) = split(":",$value);
		//if($ID == $now_owner){
		print "\t\t\t<option value=\"".htmlspecialchars($ID,ENT_QUOTES,"UTF-8")."\">".htmlspecialchars($ID,ENT_QUOTES,"UTF-8")."</option>\n";
		//}
	}
	print "\t\t</select>\n";
}
