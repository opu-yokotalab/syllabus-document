<?php
function str2otf($str){
        $out='';
        $flag=0;
        for($i=0;$i<mb_strlen($str,"UTF-8");$i++){
                $c=mb_substr($str,$i,1,"UTF-8");
                if($c == '<'){
                        ChangeFlag($flag);
                }
                if($flag){
                        $out.=$c;
                }else{
			if($c == "&"){
				$sub3str = mb_substr($str,$i+1,3,"UTF-8");
				if(mb_substr($str,$i+1,4,"UTF-8") == "amp;"){
					$out.='\\'.$c;
				}elseif($sub3str == "lt;"){
					$i+=3;
					$out.='$\langle$';
				}elseif($sub3str == "gt;"){
					$out.='$\rangle$';
					$i+=3;
				}else{
					$out.=ordUTF8($c);
				}
			}else{
                        	$out.=ordUTF8($c);
			}
                }
                if($c == '>'){
                        ChangeFlag($flag);
                }
        }
        if($flag){
                echo "\nXML PASER ERROE\n";
        }
        return $out;
}
function ordUTF8($c, $index = 0){
  $len = strlen($c);
  if ($index >= $len)
    return false;
  $h = ord($c{$index});
  //echo dechex($h).":".dechex(ord($c{$index+1})).":".dechex(ord($c{$index+2}))."\n";
  if(($h == 0xE3 && ord($c{$index+1}) == 0x80 && (ord($c{$index+2}) >= 0x81 && ord($c{$index+2}) <= 0x95 && ord($c{$index+2}) !=0x84))
  || ($h == 0xEF && ord($c{$index+1}) == 0xBC && ((ord($c{$index+2}) >= 0x88 && ord($c{$index+2}) <= 0x89)
                                || ord($c{$index+2}) == 0x8C
                                || ord($c{$index+2}) == 0x8E
                                || ord($c{$index+2}) == 0xBB
                                || ord($c{$index+2}) == 0xBD))
  || ($h == 0xEF && ord($c{$index+1}) == 0xBD && (ord($c{$index+2}) == 0x9B || ord($c{$index+2}) == 0x9D))
  ){
          return $c;
  }else if($h <= 0x7F){
    if( ($h >= 0x23 && $h <= 0x25 ) || $h == 0x7B|| $h == 0x7D ){//'#' '$' '%' '{' '}'
      return '\\'.$c;
    }
    else if($h == 0x2D){ // '-' //Consider:encodig is none or UTF-8,EUC-JP
        return "{".$c."}";
    }
    /* if using here,considering '&','&amp;','&lt;',and so on. */
    /*else if($h == 0x26){ //'&'
      return '\\&amp;';//"\UTF{".dechex($h)."}";
    }*/
    /* attention: '<', '>' and '"' are using as xml tags or enclose attribute value ,otherwise they're entity.*/
    else if($h == 0x22                //'"'
           || $h == 0x27                //'''
           || $h == 0x3C || $h == 0x3E  // '<' '>'
            ){
      return "\UTF{".dechex($h)."}";//
    }
    else if($h == 0x5C){ // '\'
      return "\$\\backslash\$";
    }
    else if($h == 0x5E || $h == 0x7E){ // '^' '~'
      return "\\".$c."{}";
    }
    /*pay attention, using '_' in xml tags*/
    else if($h == 0x5F){ //'_'
      return '\\'.$c;
    }
    else if ($h == 0x2A || $h == 0x7C){ // ,'* ''|'
      return "\$".$c."\$";
    }
    else{
      return $c;
    }
  }
  else if ($h < 0xC2)
    return false;
  else if ($h <= 0xDF && $index < $len - 1) {
    return "\UTF{".dechex( ($h & 0x1F) <<  6 | (ord($c{$index+1}) & 0x3F))."}";
  }
  else if ($h <= 0xEF && $index < $len - 2) {
    return "\UTF{".dechex(($h & 0x0F) << 12 | (ord($c{$index+1}) & 0x3F) << 6
                             | (ord($c{$index+2}) & 0x3F))."}";
  }
  else if ($h <= 0xF4 && $index < $len - 3) {
    return "\UTF{".dechex(($h & 0x0F) << 18 | (ord($c{$index+1}) & 0x3F) << 12
                             | (ord($c{$index+2}) & 0x3F) << 6
                             | (ord($c{$index + 3}) & 0x3F))."}";
  }
  else
    return false;
}
function ChangeFlag(&$f){
        $f = ~ $f;
}
?>
